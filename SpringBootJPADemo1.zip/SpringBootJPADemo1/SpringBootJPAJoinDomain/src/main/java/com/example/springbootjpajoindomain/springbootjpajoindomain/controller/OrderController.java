package com.example.springbootjpajoindomain.springbootjpajoindomain.controller;

import com.example.springbootjpajoindomain.springbootjpajoindomain.model.Customer;
import com.example.springbootjpajoindomain.springbootjpajoindomain.model.OrderRequest;
import com.example.springbootjpajoindomain.springbootjpajoindomain.repository.CustomerRepository;
import com.example.springbootjpajoindomain.springbootjpajoindomain.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class OrderController {

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    ProductRepository productRepository;

    @PostMapping("/placeOrder")
    public Customer placeOrder(@RequestBody OrderRequest request)
    {
        return  customerRepository.save(request.getCustomer());
    }

    @RequestMapping(value="/{id}", method = RequestMethod.GET)
    public Customer getOrderDetails(@PathVariable int id)
    {
        Optional resp=customerRepository.findById(id);
        Customer custResp=(Customer) resp.get();
        return custResp;
    }

    @RequestMapping(value = "/findAll", method=RequestMethod.GET)
    public List<Customer> getAllOrders()
    {
        return customerRepository.findAll();

    }
}
