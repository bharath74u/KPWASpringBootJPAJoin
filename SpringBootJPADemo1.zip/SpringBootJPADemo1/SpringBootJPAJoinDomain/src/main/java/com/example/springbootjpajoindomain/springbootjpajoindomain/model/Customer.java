package com.example.springbootjpajoindomain.springbootjpajoindomain.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import com.example.springbootjpajoindomain.springbootjpajoindomain.model.Product;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString

@Entity
public class Customer {

    @Id
    @GeneratedValue
    private int id;

    private String CustName;
    private String email;
    private String geneder;

    @OneToMany(targetEntity = Product.class, cascade = CascadeType.ALL)
    @JoinColumn(
            name = "cp_fk", referencedColumnName = "id"
    )
    private List<Product> productList;

}
