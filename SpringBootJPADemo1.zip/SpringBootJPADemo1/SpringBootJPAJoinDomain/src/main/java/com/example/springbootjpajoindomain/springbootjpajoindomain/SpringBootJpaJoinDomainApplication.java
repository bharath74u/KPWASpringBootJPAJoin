package com.example.springbootjpajoindomain.springbootjpajoindomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaJoinDomainApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJpaJoinDomainApplication.class, args);
    }

}
