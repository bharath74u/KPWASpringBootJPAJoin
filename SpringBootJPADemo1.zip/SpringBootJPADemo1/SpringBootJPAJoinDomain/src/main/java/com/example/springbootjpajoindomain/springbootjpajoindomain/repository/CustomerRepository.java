package com.example.springbootjpajoindomain.springbootjpajoindomain.repository;

import com.example.springbootjpajoindomain.springbootjpajoindomain.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
